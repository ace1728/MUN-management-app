package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff2)
        val name_input = findViewById<EditText>(R.id.name_edit_text)
        val del_input = findViewById<EditText>(R.id.del_edit_text)
        val com_input = findViewById<EditText>(R.id.com_edit_text)
        val add_butn = findViewById<Button>(R.id.add_btn2)
        val bt=findViewById<ImageButton>(R.id.b3)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff2, MainActivity2::class.java))
        }
        add_butn.setOnClickListener {
            val name_text = name_input.text.toString().trim()
            val del_text = del_input.text.toString().trim()
            val com_text = com_input.text.toString().trim()
            db.ADD_DATA2(name_text, del_text, com_text)
            Toast.makeText(this@addstuff2, "The award is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff2, execboard::class.java))

        }
    }
}