package com.kc.sqlite

import Adapters1
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_searchaward.*

class searchaward : AppCompatActivity() {
    lateinit var lists:ArrayList<Award>
    lateinit var DBS1: SQHelper
    lateinit var datas1: Cursor
    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_searchaward)

        lists=ArrayList<Award>()
        DBS1 = SQHelper(applicationContext)
        val adapter = Adapters1(applicationContext,lists)
        recyclerView = findViewById<RecyclerView>(R.id.lists1)
       val bd=findViewById<Button>(R.id.bestdel)
        bd.setOnClickListener {
            datas1 = DBS1.best_del
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas1.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas1.moveToNext()) {
                lists.add(
                    Award(
                        datas1.getString(0),
                        datas1.getString(1),
                        datas1.getString(2)
                    )
                )
            }
            lists1.layoutManager = GridLayoutManager(applicationContext, 1)
            lists1.adapter = adapter
        }
        val back=findViewById<ImageButton>(R.id.b1)
        back.setOnClickListener {
            startActivity(Intent(this@searchaward,MainActivity2::class.java))
        }
        val vb=findViewById<Button>(R.id.verb)
        vb.setOnClickListener {
            datas1 = DBS1.verbal
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas1.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas1.moveToNext()) {
                lists.add(
                    Award(
                        datas1.getString(0),
                        datas1.getString(1),
                        datas1.getString(2)
                    )
                )
            }
            lists1.layoutManager = GridLayoutManager(applicationContext, 1)
            lists1.adapter = adapter
        }
        val bp=findViewById<Button>(R.id.bpp)
        bp.setOnClickListener {
            datas1 = DBS1.pop
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas1.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas1.moveToNext()) {
                lists.add(
                    Award(
                        datas1.getString(0),
                        datas1.getString(1),
                        datas1.getString(2)
                    )
                )
            }
            lists1.layoutManager = GridLayoutManager(applicationContext, 1)
            lists1.adapter = adapter
        }
        val hono=findViewById<Button>(R.id.hon)
        hono.setOnClickListener {
            datas1 = DBS1.hm
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas1.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas1.moveToNext()) {
                lists.add(
                    Award(
                        datas1.getString(0),
                        datas1.getString(1),
                        datas1.getString(2)
                    )
                )
            }
            lists1.layoutManager = GridLayoutManager(applicationContext, 1)
            lists1.adapter = adapter
        }


    }
}