package com.kc.sqlite

import Adapter6
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_spo.*

class spo : AppCompatActivity() {
    lateinit var lists:ArrayList<Sponsor>
    lateinit var DB5: SQHelper
    lateinit var data5: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spo)
        val btn=findViewById<Button>(R.id.addsp)
        btn.setOnClickListener {
            startActivity(Intent(this@spo,addstuff5::class.java))
        }
        lists=ArrayList<Sponsor>()
        DB5 = SQHelper(applicationContext)
        data5 = DB5.data_get5
        val adapter = Adapter6(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list5)
        ShowData5()
        list5.layoutManager = GridLayoutManager(applicationContext, 1)
        list5.adapter = adapter
    }
    fun ShowData5() {

        if (data5.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data5.moveToNext()) {
            lists.add(
                Sponsor(
                    data5.getString(0),
                    data5.getString(1),
                    data5.getString(2)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData5()
    }
}