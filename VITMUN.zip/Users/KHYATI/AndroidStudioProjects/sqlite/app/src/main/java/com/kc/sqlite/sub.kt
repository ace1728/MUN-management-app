package com.kc.sqlite
class Delegate(var id:String,var name:String,var phone_num:String,var country:String)
class Faculty(var id1: String,var fname:String,var department:String,var email :String)
class Award(var awardname: String,var delid:String,var comname: String)
class Payment(var transid:String,var spname:String)
class Finance(var trid:String,var Amount:String,var Description:String,var orgid:String)
class Sponsor(var sname:String,var oname:String,var contact:String)
class Committee(var cname:String,var mem:String,var rn:String,var chair:String)
class Organiser(var orid:String,var orname:String,var po:String,var ct:String)
class Institute(var insid:String,var insname:String,var tp:String)
class Managing(var coname:String,var oid:String,var fid:String)
class Accomodation(var rid:String,var hotel:String,var rno:String,var nob:String,var inid:String)
class ExecutiveBoard(var ebid:String,var ebname:String,var des:String,var contct:String,var ebcname:String)

