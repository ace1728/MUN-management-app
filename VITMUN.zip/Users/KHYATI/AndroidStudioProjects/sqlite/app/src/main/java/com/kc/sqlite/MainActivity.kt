package com.kc.sqlite

import Adapter
import android.app.Dialog
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var lists:ArrayList<Delegate>
    lateinit var DB:SQHelper
    lateinit var data:Cursor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val go = findViewById<Button>(R.id.go_sub)
        go.setOnClickListener {
            startActivity(Intent(this@MainActivity, addstuff::class.java))
        }

       

        lists = ArrayList<Delegate>()
        DB = SQHelper(applicationContext)
        data = DB.data_get
        val adapter = Adapter(applicationContext, lists)
        val recycler = findViewById<RecyclerView>(R.id.list)
        ShowData()
        list.layoutManager=GridLayoutManager(applicationContext,1)
        list.adapter=adapter
    }
        fun ShowData(){

            if(data.count==0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()   }
                while (data.moveToNext()) {
                    lists.add(
                        Delegate(
                            data.getString(0),
                            data.getString(1),
                            data.getString(2),
                            data.getString(3)
                        )
                    )
                                         }
        }

    override fun onStart() {
        super.onStart()
        ShowData()
    }



}







