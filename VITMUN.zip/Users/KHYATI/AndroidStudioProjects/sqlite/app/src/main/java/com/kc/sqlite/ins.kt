package com.kc.sqlite

import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_ins.*

class ins : AppCompatActivity() {
    lateinit var lists:ArrayList<Institute>
    lateinit var DB8: SQHelper
    lateinit var data8: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ins)
        val btn=findViewById<Button>(R.id.addi)
        btn.setOnClickListener {
            startActivity(Intent(this@ins,addstuff8::class.java))
        }
        lists=ArrayList<Institute>()
        DB8 = SQHelper(applicationContext)
        data8 = DB8.data_get8
        val adapter = Adapter9(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list8)
        ShowData8()
        list8.layoutManager = GridLayoutManager(applicationContext, 1)
        list8.adapter = adapter
    }
    fun ShowData8() {

        if (data8.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data8.moveToNext()) {
            lists.add(
                Institute(
                    data8.getString(0),
                    data8.getString(1),
                    data8.getString(2)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData8()
    }
}