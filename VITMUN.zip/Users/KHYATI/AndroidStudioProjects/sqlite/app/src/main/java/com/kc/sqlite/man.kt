package com.kc.sqlite

import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_man.*

class man : AppCompatActivity() {
    lateinit var lists:ArrayList<Managing>
    lateinit var DB9: SQHelper
    lateinit var data9: Cursor
    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_man)
        val gom = findViewById<Button>(R.id.go_man)
        gom.setOnClickListener {
            startActivity(Intent(this@man, addstuff9::class.java))
        }
        val se=findViewById<Button>(R.id.search1)
        se.setOnClickListener {
            startActivity(Intent(this@man,searchteam::class.java))
        }


        lists=ArrayList<Managing>()
        DB9 = SQHelper(applicationContext)
        data9 = DB9.data_get9
        val adapter = Adapter10(applicationContext,lists)
        recyclerView = findViewById<RecyclerView>(R.id.list9)
        ShowData9()
        list9.layoutManager = GridLayoutManager(applicationContext, 1)
        list9.adapter = adapter
    }
    fun ShowData9() {
        // lists.clear()
        //  recyclerView?.adapter?.notifyDataSetChanged()
        if (data9.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data9.moveToNext()) {
            lists.add(
                Managing(
                    data9.getString(0),
                    data9.getString(1),
                    data9.getString(2)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData9()
    }
}