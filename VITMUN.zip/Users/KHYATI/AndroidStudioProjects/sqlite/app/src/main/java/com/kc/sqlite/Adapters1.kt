
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DBS1: SQHelper
class Adapters1(var context: Context, data:ArrayList<com.kc.sqlite.Award>)  :RecyclerView.Adapter<Adapters1.ViewHoldr>() {


    var data:List<com.kc.sqlite.Award> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_fac,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val db:SQHelper
        db= SQHelper(context)

        holder.aw.text=data[position].awardname
        holder.del.text=data[position].delid
        holder.com.text=data[position].comname

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var del:TextView
        var com:TextView
        var aw:TextView



        init {
            del=item.findViewById(R.id.id1_textview)
            com=item.findViewById(R.id.phone_textview)
            aw=item.findViewById(R.id.name_textview)





        }
    }

}