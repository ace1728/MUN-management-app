package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val btn_del=findViewById<Button>(R.id.del)
        btn_del.setOnClickListener {
            var intentdel=Intent(this@MainActivity2,MainActivity::class.java)
            startActivity(intentdel)
        }
        val btn_b=findViewById<ImageButton>(R.id.next)
        btn_b.setOnClickListener {
            startActivity(Intent(this@MainActivity2,lis::class.java))
        }
        val btn_fac=findViewById<Button>(R.id.faculty)
        btn_fac.setOnClickListener {
            var intentfac=Intent(this@MainActivity2,MainActivity3::class.java)
            startActivity(intentfac)
        }
        val btn_exec=findViewById<Button>(R.id.exec)
        btn_exec.setOnClickListener {
            var intentexec=Intent(this@MainActivity2,execboard::class.java)
            startActivity(intentexec)
        }
     val btn_pay=findViewById<Button>(R.id.pay)
        btn_pay.setOnClickListener {
            var intent_pay=Intent(this@MainActivity2,test::class.java)
            startActivity(intent_pay)
        }
        val btn_fin=findViewById<Button>(R.id.fin)
        btn_fin.setOnClickListener {
            var intent_fin=Intent(this@MainActivity2,fin::class.java)
            startActivity(intent_fin)
        }
        val btn_spon=findViewById<Button>(R.id.spon)
        btn_spon.setOnClickListener {
            var intent_spon=Intent(this@MainActivity2,spo::class.java)
            startActivity(intent_spon)
        }

    }
}