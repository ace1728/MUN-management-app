package com.kc.sqlite

import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_searchaward.*
import kotlinx.android.synthetic.main.activity_searchteam.*

class searchteam : AppCompatActivity() {
    lateinit var lists:ArrayList<Managing>
    lateinit var DBS2: SQHelper
    lateinit var datas2: Cursor
    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_searchteam)
        lists=ArrayList<Managing>()
        DBS2 = SQHelper(applicationContext)
        val adapter = Adapters2(applicationContext,lists)
        recyclerView = findViewById<RecyclerView>(R.id.lists2)
        val back=findViewById<ImageButton>(R.id.b2)
        back.setOnClickListener {
            startActivity(Intent(this@searchteam,lis::class.java))
        }
        val unsc=findViewById<Button>(R.id.munsc)
        unsc.setOnClickListener {
            datas2 = DBS2.UNSC
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
        val ip=findViewById<Button>(R.id.mip)
        ip.setOnClickListener {
            datas2 = DBS2.IP
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
        val UNGA=findViewById<Button>(R.id.munga)
        UNGA.setOnClickListener {
            datas2 = DBS2.UNGA
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
        val ecofin=findViewById<Button>(R.id.mecofin)
        ecofin.setOnClickListener {
            datas2 = DBS2.ECOFIN
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
        val disec=findViewById<Button>(R.id.mdisec)
        disec.setOnClickListener {
            datas2 = DBS2.DISEC
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
        val sochum=findViewById<Button>(R.id.msochum)
        sochum.setOnClickListener {
            datas2 = DBS2.SOCHUM
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
        val unhrc=findViewById<Button>(R.id.munhrc)
        unhrc.setOnClickListener {
            datas2 = DBS2.UNHRC
            lists.clear()
            recyclerView?.adapter?.notifyDataSetChanged()
            if (datas2.count == 0) {
                Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                    .show()
            }
            while (datas2.moveToNext()) {
                lists.add(
                    Managing(
                        datas2.getString(0),
                        datas2.getString(1),
                        datas2.getString(2)
                    )
                )
            }
            lists2.layoutManager = GridLayoutManager(applicationContext, 1)
            lists2.adapter = adapter
        }
    }
}