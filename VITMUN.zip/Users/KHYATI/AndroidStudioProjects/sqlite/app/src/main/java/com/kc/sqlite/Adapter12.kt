package com.kc.sqlite

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DB11: SQHelper
class Adapter12(var context: Context, data:ArrayList<com.kc.sqlite.ExecutiveBoard>)  :RecyclerView.Adapter<Adapter12.ViewHoldr>() {


    var data:List<com.kc.sqlite.ExecutiveBoard> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_five,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val db:SQHelper
        db= SQHelper(context)
        holder.i.text=data[position].ebid
        holder.n.text=data[position].ebname
        holder.rn.text=data[position].contct
        holder.nb.text=data[position].des
        holder.ii.text=data[position].ebcname

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var i:TextView
        var n:TextView
        var rn:TextView
        var nb:TextView
        var ii:TextView




        init {
            i=item.findViewById(R.id.f1_textview)
            n=item.findViewById(R.id.f2_textview)
            rn=item.findViewById(R.id.f3_textview)
            nb=item.findViewById(R.id.f4_textview)
            ii=item.findViewById(R.id.f5_textview)






        }
    }

}

