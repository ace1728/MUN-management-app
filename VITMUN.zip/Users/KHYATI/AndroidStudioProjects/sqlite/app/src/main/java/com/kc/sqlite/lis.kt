package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton

class lis : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lis)
        val cbtn=findViewById<Button>(R.id.com)
        cbtn.setOnClickListener {
            startActivity(Intent(this@lis,comm::class.java))
        }
        val obtn=findViewById<Button>(R.id.org)
        obtn.setOnClickListener {
            startActivity(Intent(this@lis,orga::class.java))
        }
        val ibtn=findViewById<Button>(R.id.ins)
        ibtn.setOnClickListener {
            startActivity(Intent(this@lis,ins::class.java))
        }
        val mnbtn=findViewById<Button>(R.id.mbtn)
        mnbtn.setOnClickListener {
            startActivity(Intent(this@lis,man::class.java))
        }
        val m=findViewById<ImageButton>(R.id.m2)
        m.setOnClickListener {
            startActivity(Intent(this@lis,MainActivity2::class.java))
        }
        val acbtn=findViewById<Button>(R.id.aco)
        acbtn.setOnClickListener {
            startActivity(Intent(this@lis,acc::class.java))
        }
        val ebbtn=findViewById<Button>(R.id.exb)
        ebbtn.setOnClickListener {
            startActivity(Intent(this@lis,execb::class.java))
        }
    }
}