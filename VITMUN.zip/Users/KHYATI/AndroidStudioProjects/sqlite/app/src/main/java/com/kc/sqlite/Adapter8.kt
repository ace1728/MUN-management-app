package com.kc.sqlite

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DB7: SQHelper
class Adapter8(var context: Context, data:ArrayList<com.kc.sqlite.Organiser>)  :RecyclerView.Adapter<Adapter8.ViewHoldr>() {


    var data:List<com.kc.sqlite.Organiser> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_sub,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val db:SQHelper
        db= SQHelper(context)
        holder.i.text=data[position].orid
        holder.n.text=data[position].orname
        holder.p.text=data[position].po
        holder.c.text=data[position].ct

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var i:TextView
        var n:TextView
        var p:TextView
        var c:TextView




        init {
            i=item.findViewById(R.id.id_textview)
            n=item.findViewById(R.id.title_textview)
            p=item.findViewById(R.id.desc_textview)
            c=item.findViewById(R.id.desc_textview2)






        }
    }

}