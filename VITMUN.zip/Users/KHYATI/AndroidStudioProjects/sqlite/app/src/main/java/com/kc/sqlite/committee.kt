package com.kc.sqlite

import Adapter7
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_committee.*

class comm : AppCompatActivity() {
    lateinit var lists:ArrayList<Committee>
    lateinit var DB6: SQHelper
    lateinit var data6: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_committee)
        val btn=findViewById<Button>(R.id.addc)
        btn.setOnClickListener {
            startActivity(Intent(this@comm,addstuff6::class.java))
        }
        lists=ArrayList<Committee>()
        DB6 = SQHelper(applicationContext)
        data6 = DB6.data_get6
        val adapter = Adapter7(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list6)
        ShowData6()
        list6.layoutManager = GridLayoutManager(applicationContext, 1)
        list6.adapter = adapter
    }
    fun ShowData6() {

        if (data6.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data6.moveToNext()) {
            lists.add(
                Committee(
                    data6.getString(0),
                    data6.getString(1),
                    data6.getString(2),
                    data6.getString(3)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData6()
    }
}