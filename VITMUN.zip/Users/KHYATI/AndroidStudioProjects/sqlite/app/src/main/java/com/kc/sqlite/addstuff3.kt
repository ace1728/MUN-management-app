package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff3)
        val tr_input=findViewById<EditText>(R.id.tr_edit_text)
        val sp_input=findViewById<EditText>(R.id.sp_edit_text)
        val add_butn=findViewById<Button>(R.id.add_btn2)
        val bt=findViewById<ImageButton>(R.id.b4)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff3, MainActivity2::class.java))
        }
        add_butn.setOnClickListener {
            val tr_text=tr_input.text.toString().trim()
            val sp_text=sp_input.text.toString().trim()
            db.ADD_DATA3(tr_text,sp_text)
            Toast.makeText(this@addstuff3,"payment is added",Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff3,test::class.java))

        }
    }
}