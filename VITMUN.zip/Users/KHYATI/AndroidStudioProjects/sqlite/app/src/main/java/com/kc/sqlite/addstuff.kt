package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlinx.android.synthetic.main.activity_addstuff.*

class addstuff : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff)
        val title_input=findViewById<EditText>(R.id.title_edit_text)
        val desc_input=findViewById<EditText>(R.id.desc_edit_text)
        val desc_input2=findViewById<EditText>(R.id.desc_edit_text2)
        val add_butn=findViewById<Button>(R.id.add_btn)
        val bb2=findViewById<ImageButton>(R.id.ib3)
        bb2.setOnClickListener {
            startActivity(Intent(this@addstuff,MainActivity2::class.java))
        }
         add_butn.setOnClickListener {
             val name_text=title_input.text.toString().trim()
             val phone_text=desc_input.text.toString().trim()
             val country_text=desc_input2.text.toString().trim()
              db.ADD_DATA(name_text,phone_text,country_text)
             Toast.makeText(this@addstuff,"The delegate is added",Toast.LENGTH_SHORT).show()
             startActivity(Intent(this@addstuff,MainActivity::class.java))

         }

    }
}
