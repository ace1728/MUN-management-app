package com.kc.sqlite

import Adapter4
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_test.*

class test : AppCompatActivity() {
    lateinit var lists:ArrayList<Payment>
    lateinit var DB3: SQHelper
    lateinit var data3: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)
        val btn=findViewById<Button>(R.id.pp)
        btn.setOnClickListener {
            startActivity(Intent(this@test,addstuff3::class.java))
        }
        lists=ArrayList<Payment>()
        DB3 = SQHelper(applicationContext)
        data3 = DB3.data_get3
        val adapter = Adapter4(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list3)
        ShowData3()
        list3.layoutManager = GridLayoutManager(applicationContext, 1)
        list3.adapter = adapter
    }
    fun ShowData3() {

        if (data3.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data3.moveToNext()) {
            lists.add(
                Payment(
                    data3.getString(0),
                    data3.getString(1)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData3()
    }
}