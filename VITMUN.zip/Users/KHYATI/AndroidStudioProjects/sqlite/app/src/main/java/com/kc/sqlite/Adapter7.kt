
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DB6: SQHelper
class Adapter7(var context: Context, data:ArrayList<com.kc.sqlite.Committee>)  :RecyclerView.Adapter<Adapter7.ViewHoldr>() {


    var data:List<com.kc.sqlite.Committee> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_sub,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val db:SQHelper
        db= SQHelper(context)
//class Finance(var trid:String,var Amount:String,var Description:String,var orgid:String)

        holder.c.text=data[position].cname
        holder.m.text=data[position].mem
        holder.r.text=data[position].rn
        holder.ch.text=data[position].chair

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var c:TextView
        var m:TextView
        var r:TextView
        var ch:TextView




        init {
            c=item.findViewById(R.id.id_textview)
            m=item.findViewById(R.id.title_textview)
            r=item.findViewById(R.id.desc_textview)
            ch=item.findViewById(R.id.desc_textview2)






        }
    }

}