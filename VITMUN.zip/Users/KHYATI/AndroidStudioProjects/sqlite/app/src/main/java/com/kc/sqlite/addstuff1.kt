package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff1)
        val id_inp=findViewById<EditText>(R.id.id_edit_text)
        val name_input=findViewById<EditText>(R.id.name_edit_text)
        val dep_input=findViewById<EditText>(R.id.dep_edit_text)
        val email=findViewById<EditText>(R.id.email_edit_text)
        val add_butn1=findViewById<Button>(R.id.add_btn1)
        val bb2=findViewById<ImageButton>(R.id.ib2)
        bb2.setOnClickListener {
            startActivity(Intent(this@addstuff1,MainActivity2::class.java))
        }
        add_butn1.setOnClickListener {
            val id_text=id_inp.text.toString().trim()
            val name_text=name_input.text.toString().trim()
            val dep_text=dep_input.text.toString().trim()
            val em=email.text.toString().trim()
            db.ADD_DATA1(id_text,name_text,dep_text,em)
            Toast.makeText(this@addstuff1,"The faculty rep is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff1,MainActivity3::class.java))

        }
    }
}