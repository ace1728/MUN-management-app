package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff6 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff6)
        val c_input=findViewById<EditText>(R.id.c_edit_text)
        val m_input=findViewById<EditText>(R.id.m_edit_text)
        val r_input=findViewById<EditText>(R.id.r_edit_text)
        val ch_input=findViewById<EditText>(R.id.ch_edit_text)
        val btn7=findViewById<Button>(R.id.add_btn7)
        val bt=findViewById<ImageButton>(R.id.b6)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff6, MainActivity2::class.java))
        }
        btn7.setOnClickListener {
            val c_text=c_input.text.toString().trim()
            val m_text=m_input.text.toString().trim()
            val r_text=r_input.text.toString().trim()
            val ch_text=ch_input.text.toString().trim()
            db.ADD_DATA6(c_text,m_text,r_text,ch_text)
            Toast.makeText(this@addstuff6,"The record is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff6,comm::class.java))


        }
    }
}