package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff8 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff8)
        val iinput=findViewById<EditText>(R.id.ii_edit_text)
        val ninput=findViewById<EditText>(R.id.in_edit_text)
        val pinput=findViewById<EditText>(R.id.it_edit_text)
        val addbtn=findViewById<Button>(R.id.add_btn8)
        val bt=findViewById<ImageButton>(R.id.b8)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff8, MainActivity2::class.java))
        }
        addbtn.setOnClickListener {
            val itext=iinput.text.toString().trim()
            val ntext=ninput.text.toString().trim()
            val ttext=pinput.text.toString().trim()
            db.ADD_DATA8(itext,ntext,ttext)
            Toast.makeText(this@addstuff8, "The institute is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff8, ins::class.java))
        }
    }
}