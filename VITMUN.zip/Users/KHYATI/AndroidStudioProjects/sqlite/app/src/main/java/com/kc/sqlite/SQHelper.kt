package com.kc.sqlite

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class SQHelper(context: Context)  :SQLiteOpenHelper(context,SQHelper.DB_name,null,SQHelper.DB_VERSION){
    override fun onCreate(db: SQLiteDatabase?) {
      val CREATE_TABLE_DEL =
            "CREATE TABLE ${DEL_TABLE} (del_id INTEGER PRIMARY KEY , del_name TEXT, del_com TEXT, del_country TEXT);"
        val CREATE_TABLE_FAC =
            "CREATE TABLE ${FAC_TABLE} (fac_id TEXT PRIMARY KEY , fac_name TEXT, fac_dep TEXT,fac_email TEXT);"
        val CREATE_TABLE_AW =
            "CREATE TABLE ${AW_TABLE} (awname TEXT PRIMARY KEY, d_id TEXT, cname TEXT,FOREIGN KEY(d_id) REFERENCES DELEGATE(del_id));"
        val CREATE_TABLE_PAY =
            "CREATE TABLE ${PAY_TABLE} (trans_id TEXT PRIMARY KEY ,sp_name TEXT,FOREIGN KEY(sp_name) REFERENCES SPONSOR(s_name));"
        val CREATE_TABLE_FI =
            "CREATE TABLE ${FI_TABLE} (tr_id TEXT ,amnt TEXT,description TEXT,org_id TEXT,FOREIGN KEY(org_id) REFERENCES ORGANISER(o_id));"
        val CREATE_TABLE_SP=
            "CREATE TABLE ${SP_TABLE} (s_name TEXT PRIMARY KEY,o_name TEXT,ct TEXT,FOREIGN KEY(o_name) REFERENCES ORGANISER(o_name))"
        val CREATE_TABLE_CM=
            "CREATE TABLE ${CM_TABLE} (c_name TEXT PRIMARY KEY,member TEXT,r_no TEXT,chair_n TEXT)"
        val CREATE_TABLE_OR=
            "CREATE TABLE ${OR_TABLE} (o_id TEXT PRIMARY KEY,o_name TEXT,posi TEXT,cont TEXT)"
        val CREATE_TABLE_IN=
            "CREATE TABLE ${IN_TABLE} (ins_id TEXT PRIMARY KEY,ins_name TEXT,t_p TEXT)"
        val CREATE_TABLE_MA=
            "CREATE TABLE ${MA_TABLE} (co_name TEXT ,o_id TEXT,f_id TEXT,FOREIGN KEY(co_name) REFERENCES Committee(c_name),FOREIGN KEY(o_id) REFERENCES Organiser(o_id),FOREIGN KEY(f_id) REFERENCES Faculty(fac_id))"
        val CREATE_TABLE_AC=
            "CREATE TABLE ${AC_TABLE} (r_id TEXT,h_name TEXT,r_no TEXT,n_b TEXT,in_id TEXT)"
        val CREATE_TABLE_EB=
            "CREATE TABLE ${EB_TABLE} (eb_id TEXT,eb_name TEXT,des TEXT,eb_ct TEXT,eb_cname TEXT)"
   db!!.execSQL(CREATE_TABLE_DEL)
        db!!.execSQL(CREATE_TABLE_FAC)
        db!!.execSQL(CREATE_TABLE_AW)
        db!!.execSQL(CREATE_TABLE_PAY)
        db!!.execSQL(CREATE_TABLE_FI)
        db!!.execSQL(CREATE_TABLE_SP)
        db!!.execSQL(CREATE_TABLE_CM)
        db!!.execSQL(CREATE_TABLE_OR)
        db!!.execSQL(CREATE_TABLE_IN)
        db!!.execSQL(CREATE_TABLE_MA)
        db!!.execSQL(CREATE_TABLE_AC)
        db!!.execSQL(CREATE_TABLE_EB)

    }
     fun tes(db:SQLiteDatabase,tr:String){
        val te=
            "SELECT * FROM Payment where trans_id='"+tr+"'"
         db!!.execSQL(te)
     }
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val DROP_TABLE_DEL="DROP TABLE IF EXISTS $DEL_TABLE"
        val DROP_TABLE_FAC="DROP TABLE IF EXISTS $FAC_TABLE"
        val DROP_TABLE_AW="DROP TABLE IF EXISTS $AW_TABLE"
        val DROP_TABLE_PAY="DROP TABLE IF EXISTS $PAY_TABLE"
        val DROP_TABLE_FI="DROP TABLE IF EXISTS $FI_TABLE"
        val DROP_TABLE_SP="DROP TABLE IF EXISTS $SP_TABLE"
        val DROP_TABLE_CM="DROP TABLE IF EXISTS $CM_TABLE"
        val DROP_TABLE_OR="DROP TABLE IF EXISTS $OR_TABLE"
        val DROP_TABLE_IN="DROP TABLE IF EXISTS $IN_TABLE"
        val DROP_TABLE_MA="DROP TABLE IF EXISTS $MA_TABLE"
        val DROP_TABLE_AC="DROP TABLE IF EXISTS $AC_TABLE"
        val DROP_TABLE_EB="DROP TABLE IF EXISTS $EB_TABLE"
        db!!.execSQL(DROP_TABLE_DEL)
        db!!.execSQL(DROP_TABLE_FAC)
        db!!.execSQL(DROP_TABLE_AW)
        db!!.execSQL(DROP_TABLE_PAY)
        db!!.execSQL(DROP_TABLE_FI)
        db!!.execSQL(DROP_TABLE_SP)
        db!!.execSQL(DROP_TABLE_CM)
        db!!.execSQL(DROP_TABLE_OR)
        db!!.execSQL(DROP_TABLE_IN)
        db!!.execSQL(DROP_TABLE_MA)
        db!!.execSQL(DROP_TABLE_AC)
        db!!.execSQL(DROP_TABLE_EB)


        onCreate(db)
    }

    fun ADD_DATA(name_text:String,phoneno_text:String,country_text: String){
        val DB=this.writableDatabase
        val values=ContentValues()
        values.put(name,name_text)
        values.put(phone_num,phoneno_text)
        values.put(country,country_text)
        DB.insert(DEL_TABLE,null,values)
    }
    fun ADD_DATA1(fid_text:String,fname_text:String,dep_text:String,email_text:String){
        val DB1=this.writableDatabase
        val values=ContentValues()
        values.put(id1,fid_text)
        values.put(fname,fname_text)
        values.put(department,dep_text)
        values.put(email,email_text)
        DB1.insert(FAC_TABLE,null,values)
    }
    fun ADD_DATA2(name_text:String,de_id:String,com: String){
        val DB2=this.writableDatabase
        val values=ContentValues()
        values.put(awardname,name_text)
        values.put(delid,de_id)
        values.put(comname,com)


        DB2.insert(AW_TABLE,null,values)
    }
    fun ADD_DATA3(tr_text:String,sp_text: String){
        val DB3=this.writableDatabase
        val values=ContentValues()
        values.put(transid,tr_text)
        values.put(spname,sp_text)


        DB3.insert(PAY_TABLE,null,values)
    }
    fun ADD_DATA4(tr_text:String,am_text: String,des_text:String,org_text:String){
        val DB4=this.writableDatabase
        val values=ContentValues()
        values.put(trid,tr_text)
        values.put(Amount,am_text)
        values.put(Description,des_text)
        values.put(orgid,org_text)
        DB4.insert(FI_TABLE,null,values)
    }
    fun ADD_DATA5(s_text:String,o_text:String,c_text:String){
        val DB5=this.writableDatabase
        val values=ContentValues()
        values.put(sname,s_text)
        values.put(oname,o_text)
        values.put(contact,c_text)
        DB5.insert(SP_TABLE,null,values)
    }
    fun ADD_DATA6(c_text:String,m_text:String,r_text:String,ch_text:String){
        val DB6=this.writableDatabase
        val values=ContentValues()
        values.put(cname,c_text)
        values.put(mem,m_text)
        values.put(rn,r_text)
        values.put(chair,ch_text)
        DB6.insert(CM_TABLE,null,values)
    }
    fun ADD_DATA7(c_text:String,m_text:String,r_text:String,ch_text:String){
        val DB7=this.writableDatabase
        val values=ContentValues()
        values.put(orid,c_text)
        values.put(orname,m_text)
        values.put(po,r_text)
        values.put(ct,ch_text)
        DB7.insert(OR_TABLE,null,values)
    }
    fun ADD_DATA8(i_text:String,n_text:String,t_text:String){
        val DB8=this.writableDatabase
        val values=ContentValues()
        values.put(insid,i_text)
        values.put(insname,n_text)
        values.put(tp,t_text)
        DB8.insert(IN_TABLE,null,values)
    }
    fun ADD_DATA9(c_text:String,o_text:String,f_text:String){
        val DB9=this.writableDatabase
        val values=ContentValues()
        values.put(coname,c_text)
        values.put(oid,o_text)
        values.put(fid,f_text)
        DB9.insert(MA_TABLE,null,values)
    }
    fun ADD_DATA10(ri_text:String,h_text:String,rn_text:String,nb_text:String,in_text:String){
        val DB10=this.writableDatabase
        val values=ContentValues()
        values.put(rid,ri_text)
        values.put(hotel,h_text)
        values.put(rno,rn_text)
        values.put(nob,nb_text)
        values.put(inid,in_text)
        DB10.insert(AC_TABLE,null,values)
    }
    fun ADD_DATA11(ri_text:String,h_text:String,rn_text:String,nb_text:String,in_text:String){
        val DB11=this.writableDatabase
        val values=ContentValues()
        values.put(ebid,ri_text)
        values.put(ebname,h_text)
        values.put(des,rn_text)
        values.put(contct,nb_text)
        values.put(ebcname,in_text)
        DB11.insert(EB_TABLE,null,values)
    }
    val data_get:Cursor get() {
        val DB:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB.rawQuery("select * from "+ DEL_TABLE,null)
        return data
    }


    val data_get1:Cursor get() {
        val DB1:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB1.rawQuery("select * from "+ FAC_TABLE,null)
        return data
    }
    val data_get2:Cursor get() {
        val DB2:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB2.rawQuery("select * from "+ AW_TABLE,null)
        return data
    }
    val data_get3:Cursor get() {
        val DB3:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB3.rawQuery("select * from "+ PAY_TABLE,null)
        return data
    }
    val data_get4:Cursor get() {
        val DB4:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB4.rawQuery("select * from "+ FI_TABLE,null)
        return data
    }
    val data_get5:Cursor get(){
        val DB5:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB5.rawQuery("select * from "+ SP_TABLE,null)
        return data
    }
    val data_get6:Cursor get(){
        val DB6:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB6.rawQuery("select * from "+ CM_TABLE,null)
        return data
    }
    val data_get7:Cursor get(){
        val DB7:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB7.rawQuery("select * from "+ OR_TABLE,null)
        return data
    }
    val data_get8:Cursor get(){
        val DB8:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB8.rawQuery("select * from "+ IN_TABLE,null)
        return data
    }
    val data_get9:Cursor get(){
        val DB9:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB9.rawQuery("select * from "+ MA_TABLE,null)
        return data
    }
    val data_get10:Cursor get(){
        val DB10:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB10.rawQuery("select * from "+ AC_TABLE,null)
        return data
    }
    val data_get11:Cursor get(){
        val DB11:SQLiteDatabase=this.writableDatabase
        var data:Cursor=DB11.rawQuery("select * from "+ EB_TABLE,null)
        return data
    }
    val best_del:Cursor get() {
        val DBS1:SQLiteDatabase=this.writableDatabase
        var aw="'Best Delegate'"
        var data:Cursor=DBS1.rawQuery("select * from "+ AW_TABLE+" where "+awardname+" = "+aw,null)

        return data
    }
    val verbal:Cursor get() {
        val DBS1:SQLiteDatabase=this.writableDatabase
        var aw="'Verbal Mention'"
        var data:Cursor=DBS1.rawQuery("select * from "+ AW_TABLE+" where "+awardname+" = "+aw,null)

        return data
    }
    val pop:Cursor get() {
        val DBS1:SQLiteDatabase=this.writableDatabase
        var aw="'Best Position Paper'"
        var data:Cursor=DBS1.rawQuery("select * from "+ AW_TABLE+" where "+awardname+" = "+aw,null)

        return data
    }
    val hm:Cursor get() {
        val DBS1:SQLiteDatabase=this.writableDatabase
        var aw="'Honorable Mention'"
        var data:Cursor=DBS1.rawQuery("select * from "+ AW_TABLE+" where "+awardname+" = "+aw,null)

        return data
    }
    /*
   1.Economic and Finance Committee (ECOFIN)
   2.Disarmament and International Security Committee (DISEC)
   3.Social, Humanitarian, and Cultural Committee (SOCHUM)
   4.United Nations Human Rights Council (UNHRC)
   5.United Nations Security Council (UNSC)
   6.International Press
   7.United Nations General Assembly (UNGA) */
    val UNSC:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'UNSC'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    val IP:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'International Press'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    val UNGA:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'UNGA'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    val ECOFIN:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'ECOFIN'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    val DISEC:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'DISEC'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    val SOCHUM:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'SOCHUM'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    val UNHRC:Cursor get() {
        val DBS2:SQLiteDatabase=this.writableDatabase
        var aw="'UNHRC'"
        var data:Cursor=DBS2.rawQuery("select * from "+ MA_TABLE+" where "+coname+" = "+aw,null)

        return data
    }
    companion object{
        private val DB_VERSION=1
        private val DB_name="proj.db"
        private val DEL_TABLE="Delegate"
        private val id="del_id"
        private val name="del_name"
        private val phone_num="del_com"
        private val country="del_country"
        private val FAC_TABLE="Faculty"
        private val id1="fac_id"
        private val fname="fac_name"
        private val department="fac_dep"
        private val email="fac_email"
        //awardname: String,var delid:String,var comname
        private val AW_TABLE="Award"
        private val awardname="awname"
        private val delid="d_id"
        private val comname="cname"
//class Payment(var transid:String,var spname:String)
        private val PAY_TABLE="Payment"
        private val transid="trans_id"
        private val spname="sp_name"
//class Finance(var trid:String,var Amount:String,var Description:String,var orgid:String)
        private val FI_TABLE="Finance"
        private val trid="tr_id"
        private val Amount="amnt"
        private val Description="description"
        private val orgid="org_id"
  //      class Sponsor(var sname:String,var oname:String,var contact:String)
        private val SP_TABLE="Sponsor"
        private val sname="s_name"
        private val oname="o_name"
        private val contact="ct"
//class Committee(var cname:String,var mem:String,var rn:String,var chair:String)
        private val CM_TABLE="Committee"
        private val cname="c_name"
        private val mem="member"
        private val rn="r_no"
        private val chair="chair_n"
        //class Organiser(var orid:String,var orname:String,var po:String,var ct:String)
        private val OR_TABLE="Organiser"
        private val orid="o_id"
        private val orname="o_name"
        private val po="posi"
        private val ct="cont"
//class Institute(var insid:String,var insname:String,var tp:String)
        private val IN_TABLE="Institute"
        private val insid="ins_id"
        private val insname="ins_name"
        private val tp="t_p"
//class Managing(var coname:String,var oid:String,var fid:String)
        private val MA_TABLE="Managing"
        private val coname="co_name"
        private val oid="o_id"
        private val fid="f_id"
// class Accomodation(var rid:String,var hotel:String,var rno:String,var nob:String,var inid:String)
        private val AC_TABLE="Accomodation"
        private val rid="r_id"
        private val hotel="h_name"
        private val rno="r_no"
        private val nob="n_b"
        private val inid="in_id"
 //class ExecutiveBoard(var ebid:String,var ebname:String,var des:String,var contct:String,var ebcname:String)
        private val EB_TABLE="ExecutiveBoard"
        private val ebid="eb_id"
        private val ebname="eb_name"
        private val des="des"
        private val contct="eb_ct"
        private val ebcname="eb_cname"


    }

 }