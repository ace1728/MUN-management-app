package com.kc.sqlite

import Adapter2
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.facultyrep.*

class MainActivity3 : AppCompatActivity() {
    lateinit var lists:ArrayList<Faculty>
    lateinit var DB1: SQHelper
    lateinit var data1: Cursor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.facultyrep)

        val go1 = findViewById<Button>(R.id.go_sub1)
        go1.setOnClickListener {
            startActivity(Intent(this@MainActivity3, addstuff1::class.java))
        }


        lists=ArrayList<Faculty>()
        DB1 = SQHelper(applicationContext)
        data1 = DB1.data_get1
        val adapter = Adapter2(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list1)
        ShowData1()
      list1.layoutManager = GridLayoutManager(applicationContext, 1)
       list1.adapter = adapter
    }

    fun ShowData1() {

        if (data1.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data1.moveToNext()) {
            lists.add(
                Faculty(
                    data1.getString(0),
                    data1.getString(1),
                    data1.getString(2),
                    data1.getString(3)
                )
            )
        }
    }

    override fun onStart() {
        super.onStart()
        ShowData1()
    }
}

