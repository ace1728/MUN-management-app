
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DB4: SQHelper
class Adapter5(var context: Context, data:ArrayList<com.kc.sqlite.Finance>)  :RecyclerView.Adapter<Adapter5.ViewHoldr>() {


    var data:List<com.kc.sqlite.Finance> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_sub,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val db:SQHelper
        db= SQHelper(context)
//class Finance(var trid:String,var Amount:String,var Description:String,var orgid:String)

        holder.tr.text=data[position].trid
        holder.am.text=data[position].Amount
        holder.des.text=data[position].Description
        holder.or.text=data[position].orgid

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var tr:TextView
        var am:TextView
        var des:TextView
        var or:TextView




        init {
            tr=item.findViewById(R.id.id_textview)
            am=item.findViewById(R.id.title_textview)
            des=item.findViewById(R.id.desc_textview)
            or=item.findViewById(R.id.desc_textview2)






        }
    }

}

