package com.kc.sqlite

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DB8: SQHelper
class Adapter9(var context: Context, data:ArrayList<com.kc.sqlite.Institute>)  :RecyclerView.Adapter<Adapter9.ViewHoldr>() {


    var data:List<com.kc.sqlite.Institute> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_fac,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
        val db:SQHelper
        db= SQHelper(context)

        holder.ii.text=data[position].insid
        holder.n.text=data[position].insname
        holder.t.text=data[position].tp

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var ii:TextView
        var n:TextView
        var t:TextView



        init {
            ii=item.findViewById(R.id.id1_textview)
            t=item.findViewById(R.id.phone_textview)
            n=item.findViewById(R.id.name_textview)





        }
    }

}