package com.kc.sqlite

import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_execb.*

class execb : AppCompatActivity() {
    lateinit var lists:ArrayList<ExecutiveBoard>
    lateinit var DB11: SQHelper
    lateinit var data11: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_execb)
        val btn=findViewById<Button>(R.id.addeb)
        btn.setOnClickListener {
            startActivity(Intent(this@execb,addstuff11::class.java))
        }
        lists=ArrayList<ExecutiveBoard>()
        DB11 = SQHelper(applicationContext)
        data11 = DB11.data_get11
        val adapter = Adapter12(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list11)
        ShowData11()
        list11.layoutManager = GridLayoutManager(applicationContext, 1)
        list11.adapter = adapter
    }
    fun ShowData11() {

        if (data11.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data11.moveToNext()) {
            lists.add(
                ExecutiveBoard(
                    data11.getString(0),
                    data11.getString(1),
                    data11.getString(2),
                    data11.getString(3),
                    data11.getString(4)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData11()
    }
}