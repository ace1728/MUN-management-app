package com.kc.sqlite

import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_acc.*
import kotlinx.android.synthetic.main.activity_orga.*
import kotlinx.android.synthetic.main.activity_orga.list7

class acc : AppCompatActivity() {
    lateinit var lists:ArrayList<Accomodation>
    lateinit var DB10: SQHelper
    lateinit var data10: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_acc)
        val btn=findViewById<Button>(R.id.adda)
        btn.setOnClickListener {
            startActivity(Intent(this@acc,addstuff10::class.java))
        }
        lists=ArrayList<Accomodation>()
        DB10 = SQHelper(applicationContext)
        data10 = DB10.data_get10
        val adapter = Adapter11(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list10)
        ShowData10()
        list10.layoutManager = GridLayoutManager(applicationContext, 1)
        list10.adapter = adapter
    }
    fun ShowData10() {

        if (data10.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data10.moveToNext()) {
            lists.add(
                Accomodation(
                    data10.getString(0),
                    data10.getString(1),
                    data10.getString(2),
                    data10.getString(3),
                    data10.getString(4)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData10()
    }
}