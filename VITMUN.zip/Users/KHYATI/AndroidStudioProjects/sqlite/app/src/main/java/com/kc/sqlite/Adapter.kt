
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

    lateinit var DB: SQHelper
class Adapter(var context: Context, data:ArrayList<com.kc.sqlite.Delegate>)  :RecyclerView.Adapter<Adapter.ViewHoldr>() {


     var data:List<com.kc.sqlite.Delegate> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_sub,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
         val db:SQHelper
        db= SQHelper(context)
        holder.country.text=data[position].country
        holder.desc.text=data[position].phone_num
        holder.title.text=data[position].name
        holder.id.text=data[position].id
       /* val de=Dialog(context)
        de.setContentView(R.layout.item_sub)
        val del=de.findViewById<Button>(R.id.delete_btn)*/
      /*  holder.del.setOnClickListener {
            db.delete_data(holder.id.toString())
            Toast.makeText(context,"delete",Toast.LENGTH_SHORT).show()

        }

       */
    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var title:TextView
        var id:TextView
        var desc:TextView
        var country:TextView
      //  var del:Button


        init {
            title=item.findViewById(R.id.title_textview)
            id=item.findViewById(R.id.id_textview)
            desc=item.findViewById(R.id.desc_textview)
          //  del=item.findViewById(R.id.delete_btn)
            country=item.findViewById(R.id.desc_textview2)


        }
    }

}