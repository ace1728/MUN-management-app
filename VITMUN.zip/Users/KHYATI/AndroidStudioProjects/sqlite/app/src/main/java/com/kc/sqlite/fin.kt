package com.kc.sqlite

import Adapter5
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_fin.*
import kotlinx.android.synthetic.main.activity_test.*

class fin : AppCompatActivity() {
    lateinit var lists:ArrayList<Finance>
    lateinit var DB4: SQHelper
    lateinit var data4: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fin)
        val btn=findViewById<Button>(R.id.add)
        btn.setOnClickListener {
            startActivity(Intent(this@fin,addstuff4::class.java))
        }
        lists=ArrayList<Finance>()
        DB4 = SQHelper(applicationContext)
        data4 = DB4.data_get4
        val adapter = Adapter5(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list4)
        ShowData4()
        list4.layoutManager = GridLayoutManager(applicationContext, 1)
        list4.adapter = adapter
    }
    fun ShowData4() {

        if (data4.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data4.moveToNext()) {
            lists.add(
                Finance(
                    data4.getString(0),
                    data4.getString(1),
                    data4.getString(2),
                    data4.getString(3)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData4()
    }

}