package com.kc.sqlite

import Adapter3
import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_award.*

class execboard : AppCompatActivity() {
    lateinit var lists:ArrayList<Award>
    lateinit var DB2: SQHelper
    lateinit var data2: Cursor
    lateinit var recyclerView: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_award)
        val go2 = findViewById<Button>(R.id.go_sub2)
        go2.setOnClickListener {
            startActivity(Intent(this@execboard, addstuff2::class.java))
        }
        val se=findViewById<Button>(R.id.search)
        se.setOnClickListener {
            startActivity(Intent(this@execboard,searchaward::class.java))
        }


        lists=ArrayList<Award>()
        DB2 = SQHelper(applicationContext)
        data2 = DB2.data_get2
        val adapter = Adapter3(applicationContext,lists)
        recyclerView = findViewById<RecyclerView>(R.id.list2)
        ShowData2()
        list2.layoutManager = GridLayoutManager(applicationContext, 1)
        list2.adapter = adapter

    }
    fun ShowData2() {
       // lists.clear()
      //  recyclerView?.adapter?.notifyDataSetChanged()
        if (data2.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data2.moveToNext()) {
            lists.add(
                Award(
                    data2.getString(0),
                    data2.getString(1),
                    data2.getString(2)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData2()
    }
}