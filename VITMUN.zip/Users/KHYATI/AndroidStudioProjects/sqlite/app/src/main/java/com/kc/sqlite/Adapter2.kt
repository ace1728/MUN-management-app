

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.kc.sqlite.R
import com.kc.sqlite.SQHelper
import javax.security.auth.Subject

lateinit var DB1: SQHelper
class Adapter2(var context: Context, data:ArrayList<com.kc.sqlite.Faculty>)  :RecyclerView.Adapter<Adapter2.ViewHoldr>() {


    var data:List<com.kc.sqlite.Faculty> //name of class in sub.kt file


    init {
        this.data=data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHoldr {
        val layout=LayoutInflater.from(context).inflate(R.layout.item_sub,parent,false)
        return ViewHoldr(layout)
    }


    override fun onBindViewHolder(holder: ViewHoldr, position: Int) {
          val db:SQHelper
        db= SQHelper(context)
        holder.email.text=data[position].email
        holder.dep.text=data[position].department
        holder.title.text=data[position].fname
        holder.id.text=data[position].id1

    }

    override fun getItemCount(): Int {
        return data.size
    }

    class ViewHoldr(item:View) :RecyclerView.ViewHolder(item){



        var title:TextView
        var id:TextView
        var email:TextView
        var dep:TextView



        init {
            title=item.findViewById(R.id.title_textview)
            id=item.findViewById(R.id.id_textview)
            dep=item.findViewById(R.id.desc_textview)
            email=item.findViewById(R.id.desc_textview2)



        }
    }

}