package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class addstuff4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff4)
        val t_input=findViewById<EditText>(R.id.t_edit_text)
        val a_input=findViewById<EditText>(R.id.a_edit_text)
        val d_input=findViewById<EditText>(R.id.d_edit_text)
        val o_input=findViewById<EditText>(R.id.o_edit_text)
        val btn4=findViewById<Button>(R.id.add_btn4)
        btn4.setOnClickListener {
            val t_text=t_input.text.toString().trim()
            val a_text=a_input.text.toString().trim()
            val d_text=d_input.text.toString().trim()
            val o_text=o_input.text.toString().trim()
            db.ADD_DATA4(t_text,a_text,d_text,o_text)
            Toast.makeText(this@addstuff4,"The record is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff4,fin::class.java))


        }
}
}




