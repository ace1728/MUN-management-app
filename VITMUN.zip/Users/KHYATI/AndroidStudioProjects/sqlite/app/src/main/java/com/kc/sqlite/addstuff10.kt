package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff10 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff10)
        val i_input=findViewById<EditText>(R.id.ri_edit_text)
        val n_input=findViewById<EditText>(R.id.hn_edit_text)
        val rn_input=findViewById<EditText>(R.id.rn_edit_text)
        val nb_input=findViewById<EditText>(R.id.nb_edit_text)
        val rii_input=findViewById<EditText>(R.id.rii_edit_text)
        val btn8=findViewById<Button>(R.id.add_btna)
        val bt=findViewById<ImageButton>(R.id.b10)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff10, MainActivity2::class.java))
        }
        btn8.setOnClickListener {
            val i_text=i_input.text.toString().trim()
            val n_text=n_input.text.toString().trim()
            val rn_text=rn_input.text.toString().trim()
            val nb_text=nb_input.text.toString().trim()
            val rii_text=rii_input.text.toString().trim()
            db.ADD_DATA10(i_text,n_text,rn_text,nb_text,rii_text)
            Toast.makeText(this@addstuff10,"The record is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff10,acc::class.java))


        }
    }
}