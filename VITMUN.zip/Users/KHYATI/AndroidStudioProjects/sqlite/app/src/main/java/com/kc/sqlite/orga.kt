package com.kc.sqlite

import android.content.Intent
import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_orga.*

class orga : AppCompatActivity() {
    lateinit var lists:ArrayList<Organiser>
    lateinit var DB7: SQHelper
    lateinit var data7: Cursor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orga)
        val btn=findViewById<Button>(R.id.addo)
        btn.setOnClickListener {
            startActivity(Intent(this@orga,addstuff7::class.java))
        }
        lists=ArrayList<Organiser>()
        DB7 = SQHelper(applicationContext)
        data7 = DB7.data_get7
        val adapter = Adapter8(applicationContext,lists)
        val recycler = findViewById<RecyclerView>(R.id.list7)
        ShowData7()
        list7.layoutManager = GridLayoutManager(applicationContext, 1)
        list7.adapter = adapter
    }
    fun ShowData7() {

        if (data7.count == 0) {
            Toast.makeText(applicationContext, "the database is empty", Toast.LENGTH_SHORT)
                .show()
        }
        while (data7.moveToNext()) {
            lists.add(
                Organiser(
                    data7.getString(0),
                    data7.getString(1),
                    data7.getString(2),
                    data7.getString(3)
                )
            )
        }
    }
    override fun onStart() {
        super.onStart()
        ShowData7()
    }
}