package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff5)
        val sinput=findViewById<EditText>(R.id.s_edit_text)
        val oinput=findViewById<EditText>(R.id.o_edit_text)
        val cinput=findViewById<EditText>(R.id.c_edit_text)
        val addbtn=findViewById<Button>(R.id.add_btn5)
        val bt=findViewById<ImageButton>(R.id.b5)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff5, MainActivity2::class.java))
        }
        addbtn.setOnClickListener {
            val stext=sinput.text.toString().trim()
            val otext=oinput.text.toString().trim()
            val ctext=cinput.text.toString().trim()
            db.ADD_DATA5(stext, otext, ctext)
            Toast.makeText(this@addstuff5, "The sponsor is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff5, spo::class.java))
        }
    }
}