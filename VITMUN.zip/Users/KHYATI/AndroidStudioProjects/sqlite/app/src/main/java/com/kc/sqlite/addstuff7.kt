package com.kc.sqlite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class addstuff7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db=SQHelper(applicationContext)
        setContentView(R.layout.activity_addstuff7)
        val i_input=findViewById<EditText>(R.id.oi_edit_text)
        val n_input=findViewById<EditText>(R.id.on_edit_text)
        val p_input=findViewById<EditText>(R.id.p_edit_text)
        val c_input=findViewById<EditText>(R.id.con_edit_text)
        val btn8=findViewById<Button>(R.id.add_btno)
        val bt=findViewById<ImageButton>(R.id.b7)
        bt.setOnClickListener {
            startActivity(Intent(this@addstuff7, MainActivity2::class.java))
        }
        btn8.setOnClickListener {
            val i_text=i_input.text.toString().trim()
            val n_text=n_input.text.toString().trim()
            val p_text=p_input.text.toString().trim()
            val c_text=c_input.text.toString().trim()
            db.ADD_DATA7(i_text,n_text,p_text,c_text)
            Toast.makeText(this@addstuff7,"The record is added", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this@addstuff7,orga::class.java))


        }
    }
}